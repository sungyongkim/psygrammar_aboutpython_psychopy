# aboutpython_psychopy
어바웃 파이썬 : PsychoPy
