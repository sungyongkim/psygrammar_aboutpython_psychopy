# set the display type to 'pygame'
DISPTYPE = 'pygame'
# make sure that the DISPSIZE matches your monitor resolution!
DISPSIZE = (1920, 1080)